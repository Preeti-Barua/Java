package assignment.stringcopypaste;

public class Stringone {
	
	public static void main1(String args[]) {
	// TODO Auto-generated method stub

	  String greet = "Hello! World";
	  
	    System.out.println("The string is: " + greet);

	    //checks the string length
	    System.out.println("The length of the string: " + greet.length());
}

	
	
	

     public static void main2(String args[]) {

         String greet = "Hello! ";
             System.out.println("First String: " + greet);

            String name = "World";
              System.out.println("Second String: " + name);

           // join two strings
            String joinedString = greet.concat(name);
             System.out.println("Joined String: " + joinedString);
}
     
     
     
     

public static void main3(String args[]) {
	String first = "java programming";
    String second = "java programming";
    String third = "python programming";
// compare first and second strings
boolean result1 = first.equals(second);
System.out.println("Strings first and second are equal: " + result1);

//compare first and third strings
boolean result2 = first.equals(third);
System.out.println("Strings first and third are equal: " + result2);
}




public static void main(String[] args) {

// create string using the string literal
String greet = "Hello! World";
System.out.println("The string is: " + greet);

// returns the character at 3
System.out.println("The character at 3: " + greet.charAt(3));

// returns the character at 7
System.out.println("The character at 7: " + greet.charAt(7));
}

}
