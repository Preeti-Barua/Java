package assignment.stringcopypaste;

public class StringBuff {
	   public static void main1(String[] args) 
	    { 
	        StringBuffer s = new StringBuffer("GeeksforGeeks"); 
	        int p = s.length(); 
	        int q = s.capacity(); 
	        System.out.println("Length of string GeeksforGeeks=" + p); 
	        System.out.println("Capacity of string GeeksforGeeks=" + q); 
	    } 
	   
	   
	   
	   
	   
	   public static void main2(String[] args) 
	
	    { 
	        StringBuffer s = new StringBuffer("GeeksGeeks"); 
	        s.reverse(); 
	        System.out.println(s); // returns skeeGrofskeeG 
	    } 
	   
	   
	   
	   public static void main(String[] args) 
	    { 
	        StringBuffer s = new StringBuffer("GeeksforGeeks"); 
	        s.delete(0, 5); 
	        System.out.println(s); // returns forGeeks 
	        s.deleteCharAt(7); 
	        System.out.println(s); // returns forGeek 
	    } 
	} 
	

	
	 


