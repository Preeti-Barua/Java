package assignment.stringcopypaste;

public class Stringbuilder {

	public static void main1(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuilder sb1 = new 
                StringBuilder("Welcome to Geeksforgeeks "); 
  System.out.println("Input: " + sb1); 

  // Appending the boolean value 
  sb1.append(true); 
  System.out.println("Output: " + sb1); 

  System.out.println(); 

  StringBuilder sb2 = new StringBuilder("We fail- "); 
  System.out.println("Input: " + sb2); 

  // Appending the boolean value 
  sb2.append(false); 
  System.out.println("Output: " + sb2); 

	}
	
	
		public static void main2(String[] args) 
	    { 
	          
	        StringBuilder sbf = new 
	                       StringBuilder("Welcome geeks!"); 
	                System.out.println( sbf); 
	  
	        /* Here it appends the char argument as 
	        string to the StringBuilder */
	        sbf.append('T'); 
	        System.out.println("Result after"+ 
	                                 " appending = " + sbf); 
	  
	      
	        sbf = new StringBuilder("hello world-"); 
	                System.out.println(sbf); 
	        /* Here it appends the char argument as 
	        string to the String Builder */
	        sbf.append('#'); 
	        System.out.println("Result after appending = " +sbf);
	                                                          
	}
		public static void main3(String[] args) 
		{
			// create a StringBuilder object, 
	        // default capacity will be 16 
	        StringBuilder str = new StringBuilder(); 
	  
	        // get default capacity 
	        int capacity = str.capacity(); 
	  
	        System.out.println("Deafult Capacity of StringBuilder = "
	                           + capacity); 
	  
	        // add the String to StringBuilder Object 
	        str.append("Geek"); 
	  
	        // get capacity 
	        capacity = str.capacity(); 
	  
	        // print the result 
	        System.out.println("StringBuilder = " + str); 
	        System.out.println("Current Capacity of StringBuilder = "
	                           + capacity); 
		}
		 public static void main(String[] args) 
		    { 
		        // create a StringBuilder object 
		        // with a String passed as parameter 
		        StringBuilder 
		            str 
		            = new StringBuilder("WelcomeGeeks"); 
		  
		        // get capacity 
		        int capacity = str.capacity(); 
		  
		        // print the result 
		        System.out.println("StringBuilder = " + str); 
		        System.out.println("Capacity of StringBuilder = "
		                           + capacity); 
		    } 
		


}
