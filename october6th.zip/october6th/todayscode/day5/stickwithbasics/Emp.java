package day5.stickwithbasics;

public class Emp {
	
	private int empno, deptid;
	private boolean tempEmployee;
	

	public Emp(int i) {
		// TODO Auto-generated constructor stub
		empno =i;
	}


	public int getEmpno() {
		// TODO Auto-generated method stub
		return empno;
	}


	public void setDeptId(int i) {
		// TODO Auto-generated method stub
		deptid = i;
		
	}


	public void setTemporaryStatus(boolean b) {
		// TODO Auto-generated method stub
		tempEmployee=b;
		
	}


	public int getDeptId() {
		// TODO Auto-generated method stub
		return deptid;
	}


	public  boolean getTempAccess() {
		// TODO Auto-generated method stub
		return tempEmployee;
	}

	
	
}
