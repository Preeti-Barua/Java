package day5.stickwithbasics;

public class Test {
	
	//assignment 4 and 5   almost done...
	
	public static void main(String[] args) {
		
		Presentation.startCT2();
		
		
	}
	public static void main2(String[] args) {
		
		Presentation.startCT1();
		
	}
	
	

	public static void main1(String[] args) {
		// TODO Auto-generated method stub
		boolean x = true;
		
		//when you want to make false
		
		x = false;
		
		
		

	}

}
