package day5.stickwithbasics;

public class Presentation {

	public static void startCT1() {
		// TODO Auto-generated method stub
		int empno =23;
		Emp empx =new Emp(empno);
		boolean status = Logic.updateEmployee(empx);
		if(status == true  ) // it works,  but was not needed, we can write  if(status)
		{
			System.out.println("employee updated");
			
		}
		else
			System.out.println("employee not updated");
		
	}

	public static void startCT2() {
		// TODO Auto-generated method stub
		int empno =45;
		Emp x = Logic.getEmployeeDetails(empno);
		System.out.println(x.getEmpno());
		System.out.println(x.getDeptId());
		System.out.println(x.getTempAccess());
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
