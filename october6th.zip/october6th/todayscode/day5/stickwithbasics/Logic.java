package day5.stickwithbasics;

public class Logic {

	public static boolean updateEmployee(Emp empx) {
		// TODO Auto-generated method stub
		boolean status = false;
		if(empx.getEmpno() == 3)
			  status = true;
		else
			 status = false;//this line is stupid
		return status;
	}

	public static Emp getEmployeeDetails(int empno) {
		// TODO Auto-generated method stub
		Emp empx =new Emp(empno);
		if(empno == 3)
		{
			empx.setDeptId(4);
			empx.setTemporaryStatus(false);
			
			
		}
		else
		{
			empx.setDeptId(5);
			empx.setTemporaryStatus(true);
			
			
		}
		
		
		return empx;
	}

}
