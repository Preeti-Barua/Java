package interfacee;



	

public class BankAccount implements Creditcard {
	int amount=20;
	
	
	
	
	 public void Rupees()
	 {
		 
		 
		 
		 System.out.println("In Rupees the amount is equalivalent to::"+amount);
	 }
	 public void Dollar()
	 {
		double totDollar=amount /73.79;
		 System.out.println("In Dollar the amount is equivalent to::"+totDollar);
	 }
	public  void Pounds()
	 {
		double totPounds= amount / 96.3;
		 System.out.println("In Pounds the amount is equivalent to::"+ totPounds);
	 }
	
	

}



