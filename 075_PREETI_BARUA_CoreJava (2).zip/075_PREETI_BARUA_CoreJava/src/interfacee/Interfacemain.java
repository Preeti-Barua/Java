package interfacee;



public class Interfacemain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BankAccount b= new BankAccount();
		b.Rupees();
		b.Dollar();
		b.Pounds();

	}

}
