package interfacee;

public interface Creditcard {

	
	abstract void Rupees();
	abstract void Dollar();
	abstract void Pounds();
	
	
	
}
