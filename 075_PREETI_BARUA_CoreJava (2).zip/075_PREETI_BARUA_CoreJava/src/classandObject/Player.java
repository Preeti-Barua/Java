package classandObject;



class Playerone


{
	
	String name;
	int age;
	String country;
	int totalrun;
	
	
	
	Playerone(String name, int age, String  country, int totalrun)
	{
		this.name=name;
		this.age=age;
		this.country=country;
		this.totalrun=totalrun;
		this.score();
		
		
	}


void Disp()
{     
	System.out.println(name);
	System.out.println(age);
	System.out.println(country);
	System.out.println(totalrun);
	
	  
}


void score(){
	 
	
	   if(totalrun>5000)
	   {
		   Disp();
	   }
	    
}
}

public class Player {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Playerone p= new Playerone("a",23,"Ind",5500);
	//	p.score();
		Playerone p1= new Playerone("c",22,"nz",3000);
	//	p1.score();
		Playerone p2= new Playerone("p",26,"aus",2000);
	//	p2.score();
		Playerone p3= new Playerone("b",21,"ban",1000);
	//	p3.score();
		Playerone p4= new Playerone("acpb",24,"SL",8000);
	//	p4.score();
		
		

	}

}
