package classandObject;
import java.util.Scanner;




class StudentTwo 
{
	 	int id;
	 	String name;
	 	float mark;

void readData()
  {
	   Scanner s= new Scanner(System.in);
	   System.out.println("enter id");
	   id=s.nextInt();
	   System.out.println("enter name");
	   name=s.next();
	   System.out.println("enter result");
	   mark=s.nextFloat();
	   s.close();
	   
  }

void display()
{
	System.out.println("id is" + id);
	System.out.println("name is" +name);
	System.out.println(" result is" +mark);
}

}

public class Studentone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	          StudentTwo s[]= new StudentTwo[4];            
	          
	          for(int i=0;i<s.length;i++)
	          {
	        	  s[i]= new StudentTwo();
	        	  //creates memory to heap
	        	  s[i].readData();
	        	  s[i].display();
	        	  
	          }
	          
		}

	}
