package labworksday4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Snake {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner sc= new Scanner(System.in);
		int a= sc.nextInt();   
		
		
		HashMap<Integer, Integer> mapone = new HashMap<>();
		for(int i=0;i<a;i++)
		{
			int x=sc.nextInt();  //head
			int y=sc.nextInt();  //tail
			
			mapone.put(x, y);
		}
		
		
	    int n=sc.nextInt();
		ArrayList<Integer>css=new ArrayList<Integer>();
		for(int i=0;i<n;i++)
		{
			css.add(sc.nextInt());
		}
		
		int present=0;
		for(int i=0;i<n;i++)
		{
			 present=present+css.get(i);
			 if(mapone.containsKey(present))
			    {
				 	present=mapone.get(present);    
			    }
			
		}
		System.out.println("present is:"+present);

	}


	}


