package labworksday4;

import java.util.ArrayList;
import java.util.Scanner;

public class Shabdhkhosh {


		

 
	static int z = 0;
	static ArrayList<String> al = new ArrayList<String>();
	static ArrayList<String> vi=new ArrayList<String>();
	


	static void find(ArrayList<String> as, String d) {
		
		for (String s : as) {
			if(al.size()==as.size()-1) {
				al.add(d);
			}
			if (s!= d) {
				if (compare(d,s)) {
					if(al.size()==as.size())
						break;
					al.add(d);
					vi.add(d);
					find(as, s);
				}				
			}
//			if(al.size()==as.size())
//				break;
		}
		vi.add(d);
		if(al.size()!=as.size())
			{
			al.clear();
			if(!(unvis(as,vi).equals("")))
			find(as,unvis(as, vi));
			}
	}

	
	static String unvis(ArrayList<String> at,ArrayList<String> ar) {
		String h="";
		
		for(String a:at) {
			boolean l=false;
			for(String b:ar) {
				if(a.equals(b))
					{
					l=true;
					break;
					}
			}
			if(!l) {h=a;
				break;
			}
			
		}
		return h;
	}
	
	
	
	static boolean compare(String a, String b) {

		boolean l = false;
		int r = a.length();
		int m = b.length();
		int min;
		if (r - m >= 0)
			min = m;
		else {
			min = r;
		}
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < m; j++) {
				if (a.charAt(i) == b.charAt(j)) {
					z++;

					for (int v = j + 1; v < min; v++) {
						if (((i + v) < r && (j + v) < m) && (a.charAt(i + v) == b.charAt(j + v))) {
							z++;
							if (((v + i) == (r - 1)) && (z > 2)) {
								l = true;
							}
						} else {
							z = 0;
							break;
						}
					}
				} else {
					z = 0;
				}
			}
		}
		return l;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number of words:");
		;
		int n = s.nextInt();

		ArrayList<String> as=new ArrayList<String>();
		
		for (int i = 0; i < n; i++) {
			System.out.println("Enter word no,- " + (i + 1));
			String t;
			do {
				t = s.next();
				if (t.length() > 30)
					System.out.println("Enter another word,this has more than 30 alphabets");
			} while (t.length() > 30);
			as.add(t) ;
		}

		find(as,as.get(0));
		if (al.size() == as.size()) {
			for (String v : al) {
				System.out.println(v);
			}
		} else {
			System.out.println("Chain couldn't be formed!");
		}

	}


}

	


