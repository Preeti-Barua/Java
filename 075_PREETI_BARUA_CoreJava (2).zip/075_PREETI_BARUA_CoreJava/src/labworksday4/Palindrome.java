package labworksday4;

import java.util.ArrayList;
import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	

		
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter a string");
				String str = sc.next().toLowerCase();
				sc.close();

				System.out.println(findPalindrome(str));

			}

			private static String findPalindrome(String str)
			{
				ArrayList<Integer> a = new ArrayList<>();
				int begin = 0;
				int end = str.length() - 1;
				int ml = 0;
				int mr = 0;
				
				for(begin = 0; begin < end-2; begin++)
				{
					while(begin != end)
					{
						if(str.charAt(begin) == str.charAt(end))
						{
							if((begin+end)%2 == 0)
							{
								ml = (begin+end)/2;
								mr = ml;
							}
							else
							{
								ml = (begin+end)/2;
								mr = ml+1;
							}
							while(ml != begin && mr != end)
							{
								if(str.charAt(ml) == str.charAt(mr))
								{
									ml--;
									mr++;
								}
								else
								{
									ml = 0;
									mr = 0;
									break;
								}
							}
						}

						end--;
					}
					if(mr != 0)
					{
						a.add(ml);
						a.add(mr);
					}
					ml = 0;
					mr = 0;
					end = str.length() - 1;
				}
				
				ArrayList<String> pal = new ArrayList<>();
				
				for(int i = 0; i < a.size(); i = i+2)
				{
					pal.add(str.substring(a.get(i), a.get(i+1)+1));
				}
				String result;
				if(pal.isEmpty())
					result = "No palindrome found in the string.";
				else
					result = sortLexicographically(pal);
				return result;
			}

			private static String sortLexicographically(ArrayList<String> pal)
			{
				for(int i = 0; i < pal.size()-1; i++)
				{
					if(pal.get(i).compareTo(pal.get(i+1)) > 0)
					{
						String temp = pal.get(i);
						pal.set(i, pal.get(i+1));
						pal.set(i+1, temp);
					}
					
					if(pal.get(i).length() < pal.get(i+1).length())
					{
						String temp = pal.get(i);
						pal.set(i, pal.get(i+1));
						pal.set(i+1, temp);
					}
				}
				return pal.get(0);
			}

		

	}


